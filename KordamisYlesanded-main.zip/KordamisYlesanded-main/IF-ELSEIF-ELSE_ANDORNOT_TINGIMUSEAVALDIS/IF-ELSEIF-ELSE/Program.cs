﻿namespace IF_ELSEIF_ELSE
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*1. kasutajapikkus*/
            //Küsi kasutajalt tema pikkust
            //kui ta on lühem kui 0cm, ütle võimatu pikkus
            //kui ta on lühem kui 1m, ütle juntsu
            //kui ta on lühem kui 2m, ütle tavaline kolge
            //kui ta on pikem kui 2m, ütle hiiglane

            /*2. sõnum noorukile*/
            //küsi kasutajalt kui vana ta on
            //küsi kasutajalt praegust aastaarvu
            //lahuta aastast kasutaja vanus
            //kui kasutaja on sündinud 2025-2020, ütle talle, kes sulle arvuti juba andis
            //kui kasutaja on sündinud 2020-2015, ütle talle, skibidi sigmaless
            //kui kasutaja on sündinud 2015-2010, küsi talt kas ta tahab saada programmeerijaks
            //    kui jah, ütle tubli
            //    kui ei, ütle kahju
            //kui kasutaja on sündinud enne 2010, küsi mitu rage comicsit ta täna oma redditi lugemise ajal leidis 

            /*3. suunakoodituvasti*/
            //küsi kasutajalt tema elukoha suunakoodi
            //kui suunakood on väiksem kui 5 tähte, ütle talle, 1 täht on puudu
            //kui suunakood on suurem kui 5 tähte, ütle talle, 1 täht on üle
            //kui suunakoodis on 5 tähte, ütle "ahha nüüd tean kus elad"

            /*4. töökoht*/
            //küsi kasutajalt kas ta töötab
            //kui kasutaja vastab jah, siis ütle tubli
            //kui kasutaja vastab ei, siis ütle, kahju, miks sa siis töökohta ei otsi?
            //kui kasutaja vastab otsin, siis ütle, loodan et saad varsti tööle c:

            /*5. 2FA autentija */
            //küsi kasutajalt tema parooli
            //seejärel küsi kasutajalt tema 2FA koodi,
            //kui parool on vale, ütle sissepääs keelatud
            //kui parool on õige, kontrolli 2FA koodi:
            //  kui 2FA kood on lühem kui 6 tähte, ütle sissepääs keelatud, kood on liiga lühike
            //  kui 2FA kood on pikem kui 6 tähte, ütle sissepääs keelatud, kood on liiga pikk
            //  kui 2FA kood on 6 tähte, siis lase sisse, öeldes "oled sissepääsenud"
            //NB: 2FA kood ei pea matchima eksisteeriva näitega nagu parool.
        }
    }
}
